﻿namespace FinalProject
{
    partial class Donor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Donor));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BloodBMSlevel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.DGenderTb = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.DAddressTb = new System.Windows.Forms.TextBox();
            this.DBldGrpTb = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.DNameTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.DPhoneTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.DAgeTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(231, 612);
            this.panel2.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(50, 153);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(146, 31);
            this.label15.TabIndex = 19;
            this.label15.Text = "View Donor";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(50, 528);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 31);
            this.label13.TabIndex = 17;
            this.label13.Text = "Logout";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(48, 370);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 31);
            this.label11.TabIndex = 15;
            this.label11.Text = "Dashboard";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(48, 329);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(178, 31);
            this.label12.TabIndex = 13;
            this.label12.Text = "Blood Transfer";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SeaShell;
            this.panel4.Location = new System.Drawing.Point(38, 109);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(11, 31);
            this.panel4.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(48, 282);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 31);
            this.label7.TabIndex = 11;
            this.label7.Text = "Blood Stock";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(48, 109);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 31);
            this.label8.TabIndex = 9;
            this.label8.Text = "Donor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(48, 196);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "View Patients";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 241);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Patient";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Tan;
            this.panel3.Controls.Add(this.BloodBMSlevel);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(231, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(996, 55);
            this.panel3.TabIndex = 2;
            // 
            // BloodBMSlevel
            // 
            this.BloodBMSlevel.AutoSize = true;
            this.BloodBMSlevel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BloodBMSlevel.Location = new System.Drawing.Point(281, 9);
            this.BloodBMSlevel.Name = "BloodBMSlevel";
            this.BloodBMSlevel.Size = new System.Drawing.Size(378, 31);
            this.BloodBMSlevel.TabIndex = 0;
            this.BloodBMSlevel.Text = "Blood Bank Management System";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(590, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 37);
            this.label3.TabIndex = 10;
            this.label3.Text = "Donors";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(242, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 33);
            this.label4.TabIndex = 13;
            this.label4.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(604, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 33);
            this.label5.TabIndex = 15;
            this.label5.Text = "Age";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(895, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 33);
            this.label6.TabIndex = 17;
            this.label6.Text = "Gender";
            // 
            // DGenderTb
            // 
            this.DGenderTb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGenderTb.FormattingEnabled = true;
            this.DGenderTb.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.DGenderTb.Location = new System.Drawing.Point(892, 207);
            this.DGenderTb.Name = "DGenderTb";
            this.DGenderTb.Size = new System.Drawing.Size(147, 31);
            this.DGenderTb.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(242, 312);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 33);
            this.label9.TabIndex = 19;
            this.label9.Text = "Phone";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(558, 312);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 33);
            this.label10.TabIndex = 21;
            this.label10.Text = "Address";
            // 
            // DAddressTb
            // 
            this.DAddressTb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DAddressTb.ForeColor = System.Drawing.Color.Red;
            this.DAddressTb.Location = new System.Drawing.Point(564, 350);
            this.DAddressTb.Multiline = true;
            this.DAddressTb.Name = "DAddressTb";
            this.DAddressTb.Size = new System.Drawing.Size(289, 131);
            this.DAddressTb.TabIndex = 20;
            // 
            // DBldGrpTb
            // 
            this.DBldGrpTb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DBldGrpTb.FormattingEnabled = true;
            this.DBldGrpTb.Items.AddRange(new object[] {
            "A+",
            "B+",
            "O+",
            "AB+",
            "A-",
            "B-",
            "O-",
            "AB-"});
            this.DBldGrpTb.Location = new System.Drawing.Point(892, 348);
            this.DBldGrpTb.Name = "DBldGrpTb";
            this.DBldGrpTb.Size = new System.Drawing.Size(156, 31);
            this.DBldGrpTb.TabIndex = 23;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(895, 312);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(161, 33);
            this.label14.TabIndex = 22;
            this.label14.Text = "Blood Group";
            // 
            // DNameTb
            // 
            this.DNameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DNameTb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DNameTb.ForeColor = System.Drawing.Color.Red;
            this.DNameTb.HintForeColor = System.Drawing.Color.Empty;
            this.DNameTb.HintText = "";
            this.DNameTb.isPassword = false;
            this.DNameTb.LineFocusedColor = System.Drawing.Color.DarkMagenta;
            this.DNameTb.LineIdleColor = System.Drawing.Color.MediumVioletRed;
            this.DNameTb.LineMouseHoverColor = System.Drawing.Color.DarkMagenta;
            this.DNameTb.LineThickness = 3;
            this.DNameTb.Location = new System.Drawing.Point(248, 207);
            this.DNameTb.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.DNameTb.Name = "DNameTb";
            this.DNameTb.Size = new System.Drawing.Size(289, 38);
            this.DNameTb.TabIndex = 40;
            this.DNameTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // DPhoneTb
            // 
            this.DPhoneTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DPhoneTb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DPhoneTb.ForeColor = System.Drawing.Color.Red;
            this.DPhoneTb.HintForeColor = System.Drawing.Color.Empty;
            this.DPhoneTb.HintText = "";
            this.DPhoneTb.isPassword = false;
            this.DPhoneTb.LineFocusedColor = System.Drawing.Color.DarkMagenta;
            this.DPhoneTb.LineIdleColor = System.Drawing.Color.MediumVioletRed;
            this.DPhoneTb.LineMouseHoverColor = System.Drawing.Color.DarkMagenta;
            this.DPhoneTb.LineThickness = 3;
            this.DPhoneTb.Location = new System.Drawing.Point(248, 348);
            this.DPhoneTb.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.DPhoneTb.Name = "DPhoneTb";
            this.DPhoneTb.Size = new System.Drawing.Size(266, 38);
            this.DPhoneTb.TabIndex = 41;
            this.DPhoneTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // DAgeTb
            // 
            this.DAgeTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DAgeTb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DAgeTb.ForeColor = System.Drawing.Color.Red;
            this.DAgeTb.HintForeColor = System.Drawing.Color.Empty;
            this.DAgeTb.HintText = "";
            this.DAgeTb.isPassword = false;
            this.DAgeTb.LineFocusedColor = System.Drawing.Color.DarkMagenta;
            this.DAgeTb.LineIdleColor = System.Drawing.Color.MediumVioletRed;
            this.DAgeTb.LineMouseHoverColor = System.Drawing.Color.DarkMagenta;
            this.DAgeTb.LineThickness = 3;
            this.DAgeTb.Location = new System.Drawing.Point(597, 208);
            this.DAgeTb.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.DAgeTb.Name = "DAgeTb";
            this.DAgeTb.Size = new System.Drawing.Size(213, 38);
            this.DAgeTb.TabIndex = 42;
            this.DAgeTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuThinButton21
            // 
            this.bunifuThinButton21.ActiveBorderThickness = 1;
            this.bunifuThinButton21.ActiveCornerRadius = 20;
            this.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton21.BackColor = System.Drawing.Color.White;
            this.bunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton21.BackgroundImage")));
            this.bunifuThinButton21.ButtonText = "Save";
            this.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton21.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton21.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton21.IdleBorderThickness = 1;
            this.bunifuThinButton21.IdleCornerRadius = 20;
            this.bunifuThinButton21.IdleFillColor = System.Drawing.Color.Red;
            this.bunifuThinButton21.IdleForecolor = System.Drawing.Color.White;
            this.bunifuThinButton21.IdleLineColor = System.Drawing.Color.Red;
            this.bunifuThinButton21.Location = new System.Drawing.Point(610, 528);
            this.bunifuThinButton21.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.bunifuThinButton21.Name = "bunifuThinButton21";
            this.bunifuThinButton21.Size = new System.Drawing.Size(155, 41);
            this.bunifuThinButton21.TabIndex = 43;
            this.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton21.Click += new System.EventHandler(this.bunifuThinButton21_Click);
            // 
            // Donor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1227, 612);
            this.Controls.Add(this.bunifuThinButton21);
            this.Controls.Add(this.DAgeTb);
            this.Controls.Add(this.DPhoneTb);
            this.Controls.Add(this.DNameTb);
            this.Controls.Add(this.DBldGrpTb);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.DAddressTb);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.DGenderTb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Donor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Donor";
            this.Load += new System.EventHandler(this.Donor_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label BloodBMSlevel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox DGenderTb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox DAddressTb;
        private System.Windows.Forms.ComboBox DBldGrpTb;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private Bunifu.Framework.UI.BunifuMaterialTextbox DNameTb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox DPhoneTb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox DAgeTb;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton21;
    }
}